


//array of objects
const quiz = [
{
	q:'	In which month comes right before march ? ',
	options:[],
	answer:
}
]