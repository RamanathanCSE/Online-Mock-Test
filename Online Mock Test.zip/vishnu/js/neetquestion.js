const quiz = [
{
	q:'In which month comes right before march ?',
	options:['may','september','july','febrary'],
	answer:3
},
{
	q:'what is the color of banana?',
	options:['orange','red','yellow','blue'],
	answer:2
},
{
	q:'3+4=7 ?',
	options:['true','false'],
	answer:0
},
{
	q:'44+44= ?',
	options:['86','85','88','87'],
	answer:2
},
{
	q:'in which time we can take breakfast? ',
	options:['afternoon','night','evening','morning'],
	answer:3
}


]
