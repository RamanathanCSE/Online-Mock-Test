const quiz =[
{
	q:'Which of the following languages is more suited to a structured program?',
	options:['PL/1','FORTRAN','BASIC','PASCAL'],
	answer:3


},
{
	q:'A computer assisted method for the recording and analyzing of existing or hypothetical systems is',
	options:['Data transmission','Data flow','Data capture','Data processing'],
	answer:1


},
{
	q:'The brain of any computer system is',
	options:['ALU','memeory','CPU','Control Unit'],
	answer:2


},
{
	q:'What difference does the 5th generation computer have from other generation computers?',
	options:['Technological advancement','Scientific code','Object Oriented Programming','All of the above'],
	answer:0


},
{
	q:'Which of the following computer language is used for artificial intelligence?',
	options:['FORTRAN','PROLOG','C','COBOL'],
	answer:1


},
{
	q:'A computer program that converts assembly language to machine language is',
	options:['Compiler','Interpreter','Assembler','Comparator'],
	answer:2


},
{
	q:'The time required for the fetching and execution of one simple machine instruction is',
	options:['Delay time','CPU cycle','Real time','Seek time'],
	answer:1


},
{
	q:'The time for which a piece of equipment operates is called',
	options:['Seek time','Effective time','Access time','Real time'],
	answer:1


},
{
	q:'Binary numbers need more places for counting because',
	options:['They are always big numbers','Any no. of 0 `s can be added in front of them','Binary base is small','0`s and l`s have to be properly spaced apart'],
	answer:2


},
{
	q:'Which access method is used for obtaining a record from a cassette tape?',
	options:['Direct','Sequential','Random','All of the above'],
	answer:1


},
{
	q:'The average time necessary for the correct sector of a disk to arrive at the read write head is _____',
	options:['Down time','Seek time','Rotational delay','Access time'],
	answer:2


},
{
	q:'A number that is used to control the form of another number is known as',
	options:['Map','Mask','Mamtossa','Marker'],
	answer:1


},
{
	q:'A general purpose single-user microcomputer designed to be operated by one person at a time is',
	options:['Special-purpose computer','KIPS','M','PC'],
	answer:3


},
{
	q:'ASCII stands for',
	options:['American standard code for information interchange','All purpose scientific code for information interchange','American security code for information interchange','American Scientific code for information interchange'],
	answer:0


},
{
	q:'Which device of computer operation dispenses with the use of the keyboard?',
	options:['Joystick','Light pen','Mouse','Touch'],
	answer:2


}
]