const quiz = [
{
	q:'The workers are hell bent at getting what is due to them.',
	options:['hell bent on getting','hell bent for getting','hell bent upon getting','No improvement'],
	answer:2
},
{
	q:'When it was feared that the serfs might go too far and gain their freedom from serfdom, the protestant leaders joined the princes at crushing them.',
	options:['into crushing','in crushing','without crushing','No improvement'],
	answer:1
},

{
	q:'The record for the biggest tiger hunt has not been met since 1911 when Lord Hardinge. then Viceroy of India, shot a tiger than measured 11 feet and 6 inches.',
	options:['improved','broken','bettered','No improvement'],
	answer:1
},
{
	q:'his powerful desire brought about his downfall.',
	options:['His intense desire','His desire for power','His fatal desire','No improvement'],
	answer:1
},
{
	q:'Will you kindly open the knot?',
	options:['untie','break','loose','No improvement'],
	answer:0
},
{
	q:'He sent a word to me that he would be coming late.',
	options:['sent word','had sent a word','sent words','No improvement'],
	answer:0
},
{
	q:'Whatever to our other problems. we have no shortcoming to cheap labour in India.',
	options:['default','deficit','scarcity','No improvement'],
	answer:2
},
{
	q:'I have lived in Delhi since I was four.',
	options:['am living','lived','had lived','No improvement'],
	answer:3
},
{
	q:'This telephone number is not existing.',
	options:['has not existed','does not exist','has not been existing','No improvement'],
	answer:1
},
{
	q:'I shall not go untill I am invited.',
	options:['till I am invited','Unless I am invited','if not I am invited','No improvement'],
	answer:1
},
{
	q:'He died in the year 1960 at 11pm on 14 July.',
	options:['on 14 July in the year 1960 at 11pm','in the year 1960 on 14 July at 11pm','at 11pm on 14 July in the year 1960','No improvement'],
	answer:2
},
{
	q:'Due to these reason we are all in favour of universal compulsory education.',
	options:['Out of these reasons','For these reasons','By these reasons','No improvement'],
	answer:1
},

{
	q:'n fact, if it hadn t been for his invaluable advice on so many occasions I wouldn t have achieved anything in life.',
	options:['remarkable advice','valuable advices','priceless suggestion','No improvement'],
	answer:3
},

{
	q:'Mr. Smith arrived at India in June last year.',
	options:['to','by','in','No improvement'],
	answer:2
},

{
	q:'But in all these cases conversion from scale have well-formulated.',
	options:['can be well-formulated','are well-formulated','well-formulated','No improvement'],
	answer:1
},
{
	q:'With a thundering roar the huge rocket soared up from the launching pad.',
	options:['flew up','went upwards','took off','No improvement'],
	answer:2
},
{
	q:'There is dearth of woman doctor in our state. We shall have to recruit some from the other states.',
	options:['women doctor','woman doctors','women doctors','No improvement'],
	answer:2
},
{
	q:'If you cross the line you will be disqualified.',
	options:['cross upon the line','cross on the line','cross out the line','No improvement'],
	answer:3
},
{
	q:'Why the dinosaurs died out is not known.',
	options:['it is not known','the reason is not known','that is not known','No improvement'],
	answer:3
}

]