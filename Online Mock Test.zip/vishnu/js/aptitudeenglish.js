const quiz = [
{
	q:'Fate smiles ...... those who untiringly grapple with stark realities of life.',
	options:['with','over','on','round'],
	answer:2
},
{
	q:'The miser gazed ...... at the pile of gold coins in front of him.',
	options:['avidly','admiringly','thoughtfully','earnestly'],
	answer:0
},
{
	q:'Catching the earlier train will give us the ...... to do some shopping.',
	options:['chance','luck','possibility','occasion'],
	answer:0
},
{
	q:'I saw a ...... of cows in the field.',
	options:['group','herd','swarm','flock'],
	answer:1
},
{
	q:'The grapes are now ...... enough to be picked.',
	options:['ready','mature','ripe','advanced'],
	answer:2
},
{
	q:'Success in this examination depends ...... hard work alone.',
	options:['at','over','for','on'],
	answer:3
},
{
	q:'My uncle decided to take ...... and my sister to the market.',
	options:['i','mine','me','myself'],
	answer:3
},
{
	q:'If you smuggle goods into the country, they may be ...... by the customs authority.',
	options:['possessed','punished','confiscated','fined'],
	answer:2
},
{
	q:'Man does not live by ...... alone.',
	options:['food','bread','meals','diet'],
	answer:1
},
{
	q:'Piyush behaves strangely at times and, therefore, nobody gets ...... with him.',
	options:['about','through','along','up'],
	answer:2
},
{
	q:'Rohan and Rohit are twin brothers, but they do not look ......',
	options:['unique','different','likely','alike'],
	answer:3
},
{
	q:'To err is ...... to forgive divine.',
	options:['beastly','human','inhuman','natural'],
	answer:1
},
{
	q:'The ruling party will have to put its own house ...... order.',
	options:['in','on','to','into'],
	answer:0
},
{
	q:'The battalion operating from the mountain was able to ...... three enemy divisons.',
	options:['tie on','tie up','tie down','tie with'],
	answer:1
},
{
	q:'I purposely ...... meet you during my last visit to Kashmir.',
	options:['didnt','wont t','hadn t','wouldnt'],
	answer:0
},
{
	q:'A man remains narrow minded, self compliance and ignorant unless he visits other people and ...... from them.',
	options:['earns','borrows','learns','hears'],
	answer:2
},

{
	q:'My father ...... down for a nap.',
	options:['lays','laid','lain','lie'],
	answer:0
},
{
	q:'I think they allow their children too much ......',
	options:['liberality','latitude','lassitude','levity'],
	answer:1
}
]