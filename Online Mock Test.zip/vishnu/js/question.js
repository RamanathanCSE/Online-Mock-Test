



//array of objects
const quiz = [
{
	q:'In which month comes right before march ?',
	options:['may','september','july','febrary'],
	answer:3
},
{
	q:'what is the color of banana?',
	options:['orange','red','yellow','blue'],
	answer:2
},
{
	q:'3+4=7 ?',
	options:['true','false'],
	answer:0
}


]