const quiz =[
{
	q:'Brass gets discoloured in air because of the presence of which of the following gases in air?',
	options:['Oxygen','Hydrogen sulphide','Carbon dioxide','Nitrogen'],
	answer:1
},
{
	q:'Which of the following is a non metal that remains liquid at room temperature?',
	options:['Phosphorous','Bromine','Chlorine','Helium'],
	answer:1
},
{
	q:'Chlorophyll is a naturally occurring chelate compound in which central metal is',
	options:['copper','magnesium','iron','calcium'],
	answer:1
},
{
	q:'Which of the following is used in pencils?',
	options:['Graphite','Silicon','Charcoal','Phosphorous'],
	answer:0
},
{
	q:'Which of the following metals forms an amalgam with other metals?',
	options:['Tin','Mercury','Lead','Zinc'],
	answer:1
},
{
	q:'The inert gas which is substituted for nitrogen in the air used by deep sea divers for breathing, is',
	options:['Argon','Xenon','Helium','Krypton'],
	answer:2
},
{
	q:'The gases used in different types of welding would include',
	options:['oxygen and hydrogen','oxygen, hydrogen, acetylene and nitrogen','oxygen, acetylene and argon','oxygen and acetylene'],
	answer:3
},
{
	q:'The property of a substance to absorb moisture from the air on exposure is called',
	options:['osmosis','deliquescence','efflorescence','desiccation'],
	answer:1
},
{
	q:'In which of the following activities silicon carbide is used?',
	options:['Making cement and glass','Disinfecting water of ponds','cutting very hard substances','Making casts for statues'],
	answer:2
},
{
	q:'The average salinity of sea water is',
	options:['3%','3.5%','2.5%','2%'],
	answer:1
},
{
	q:'Production of chlorofluorocarbons (CFC) gas which is proposed to be banned in India, is used in which of the following domestic products',
	options:['Television','Refrigerator','Tube light','Cooking gas'],
	answer:1
},
{
	q:'Balloons are filled with',
	options:['nitrogen','helium','oxygen','argon'],
	answer:1
},
{
	q:'Which of the following does not contain a coinage metal?',
	options:['Silver and Gold','Zinc and Gold','Copper and Silver','Copper and Gold'],
	answer:1
},
{
	q:'Which metal pollute the air of a big city?',
	options:['Copper','Chromium','Lead','Cadmium'],
	answer:2
},
{
	q:'Bell metal is an alloy of',
	options:['nickel and copper','zinc and copper','brass and nickel','tin and copper'],
	answer:3
}
]