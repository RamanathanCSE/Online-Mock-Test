const quiz = [
{
	q:'1. I 	2. immediately 	3. salary 4. my 5. want ',
	options:['43152','15432','25143','42351'],
	answer:1
},
{
	q:'1. do 	2. today 	3. you  4. must 	5. it ',
	options:['34152','21452','35421','42351'],
	answer:0
},
{
	q:'1. left 	2. the 	3. house  4. he 	5. suddenly ',
	options:['12435','12435','45123','52341'],
	answer:2
},
{
	q:'1. medicine 	2. a 	3. Neeta  4. given 	5. was',
	options:['51423','25431','42531','35421'],
	answer:3
},
{
	q:'1. of 	2. we 	3. heard  4. him 	5. had 	 ',
	options:['42351','52341','25341','25314'],
	answer:3
},
{
	q:'1. at 	2. it 	3. take  4. once 	5. away 	',
	options:['23514','14352','32514','53214'],
	answer:2
},
{
	q:'1. him 	2. the 	3. to  4. charge 	5. handover ',
	options:['42531','51342','41352','52431'],
	answer:3
},
{
	q:'1. seen 	2. going 	3. you  4. him 	5. have 	',
	options:['35214','35142','32514','35124'],
	answer:1
},
{
	q:'1. bag? 	2. you 	3. seen  4. have 	5. my 	',
	options:['51432','43512','42351','42153'],
	answer:2
},
{
	q:'1. killed 	2. a 	3. Jaswant  4. bear 	5. wild ',
	options:['31254','53124','23145','43125'],
	answer:0
},
{
	q:'1. was 	2. and 	3. Suresh  4. kind 	5. loving 	 ',
	options:['31425','54213','34251','15243'],
	answer:0
},
{
	q:'1. tea 	2. have 	3. that  4. some 	5. before 	 ',
	options:['43251','24315','24153','52431'],
	answer:2
},
{
	q:'1. not 	2. hotel 	3. comfortable  4. was 	5. the ',
	options:['34521','53412','34152','52413'],
	answer:3
},
{
	q:'1. I 	2. help 	3. not   4. you 	5. did ',
	options:['24351','15324','45231','43152'],
	answer:1
},
{
	q:'1. not 	2. Hari 	3. away   4. run 	5. did ',
	options:['13542','35412','52431','25143'],
	answer:3
}


]