const quiz = [
{
	q:'Which type of fire extinguisher is used for petroleum fire?',
	options:['Powder type','Liquid type','Soda acid type','Foam type'],
	answer:0
},
{
	q:'Which of the following is commonly called a "polyamide"?',
	options:['Terylene','Nylon','Rayon','Orlon'],
	answer:1
},
{
	q:'Epoxy resins are used as',
	options:['detergents','insecticides','adhesives','moth repellents'],
	answer:2
},
{
	q:'Detergents used for cleaning clothes and utensils contain?',
	options:['bicarbonates','bismuthates','sulphonates','nitrates'],
	answer:2
},
{
	q:'The major ingredient of leather is',
	options:['collagen','carbohydrate','polymer','nucleic acid'],
	answer:0
},
{
	q:'What are the soaps?',
	options:['Salts of silicates','Mixture of glycerol and alcohols','Sodium or potassium salts of heavier fatty acids','Esters of heavy fatty acids'],
	answer:2
},
{
	q:'How does common salt help in separating soap from the solution after saponification?',
	options:['By decreasing density of Soap','By decreasing solubility of Soap','By increasing density of Soap','By increasing solubility of Soap'],
	answer:1
},
{
	q:'In vulcanisation, natural rubber is heated with',
	options:['Carbon','Silicon','Sulphur','Phosphorous'],
	answer:2
},
{
	q:'Deep blue colour is imparted to glass by the presence of',
	options:['cupric oxide','nickel oxide','cobalt oxide','iron oxide'],
	answer:2
},
{
	q:'The type of glass used in making lenses and prisms is',
	options:['jena glass','soft glass','pyrex glass','flint glass'],
	answer:3
},
{
	q:'Which one of the following is the petroleum wax?',
	options:['Paraffin wax','Jonoba wax','Carnauba wax','Bees wax'],
	answer:0
}

]