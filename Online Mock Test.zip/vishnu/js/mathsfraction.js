const quiz =[
{
	q:'What decimal of an hour is a second ?',
	options:[ '.0025','.0256','.00027','.000126'],
	answer:2
},
{
	q:'(0.96)3 - (0.1)3 is (0.96)2 + 0.096 + (0.1)2',
	options:[ '0.86','0.95','0.97','1.06'],
	answer:0
},
{
	q:'0.1 x 0.1 x 0.1 + 0.02 x 0.02 x 0.02  is  0.2 x 0.2 x 0.2 + 0.04 x 0.04 x 0.04',
	options:[ '0.00125','0.125','0.25','0.5'],
	answer:1
},
{
	q:'If 2994 ÷ 14.5 = 172, then 29.94 ÷ 1.45 = ?',
	options:[ '0.172','1.72','17.2','172'],
	answer:2
},
{
	q:'The correct expression of 6.46 in the fractional form is:',
	options:[ '64699','64640','640100','64099'],
	answer:3
},
{
	q:'The fraction 101 27 	in decimal for is:100000',
	options:[ '101.000027','101.00027','.10127','.01027'],
	answer:2
},
{
	q:'4.036 divided by 0.04 gives :',
	options:[ '1.009','10.09','100.9','none of these'],
	answer:1
},
{
	q:'3.87 - 2.59 = ?',
	options:[ '1.20','1.2','1.27','1.28'],
	answer:1
},
{
	q:'0.04 x 0.0162 is equal to:',
	options:[ '6.48 x 10-3','6.48 x 10-4','6.48 x 10-5','6.48 x 10-6'],
	answer:1
},
{
	q:'The price of commodity X increases by 40 paise every year, while the price of commodity Y increases by 15 ',
	options:[ '2010','2011','2012','2013'],
	answer:1
}

]
