<!DOCTYPE html>
<html>
<head>
	<title>ABOUT</title>
	<style type="text/css">
		@import url("https://fonts.googleapis.com/css2?family=Goudy+Bookletter+1911&display=swap" rel="stylesheet");

		.img img{
			 float: center;
  			 width: 400px;
 			margin-left: 480px;

		}
		@media screen and (max-width: 700px){
 		.about {
 			margin-left: 0;
 			font-size: 18px;
 			float: center;
   		 }
   		 .img img{
   		 	margin-left: 100px;
   		 }
  }
      



	</style>
</head>
<body>
	<div class="about">
	<h1 style="text-align: center;font-family: timesofindia">About US</h1><br>
	
	<div class="img"><img src="img/aptitudesimple.jpg"></div><br>

	<p style="font-size: 18px;text-align: center;">&ensp;&ensp;This is team of Online Mock Test in Thiagarajar college of Engineering, Madurai...here its our website its used to prepare for your online exams and courses...any doubts or queries please contact us...thank you !!! </p>

	<h1 style="text-align: center;font-family: timesnewroman">Email-id : vishnukumarlk@student.tce.edu</h1>
	<h1 style="text-align: center;font-family: timesofindia">Mobile no : 9087654321</h1>
	<footer style="text-align: center;font-weight: bold;padding: 15px 15px;color: blue;">
		@copyrights OMT_group 2022-2023
	</footer>
</div>

</body>
</html>