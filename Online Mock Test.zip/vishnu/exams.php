<!DOCTYPE html>
<html>
<head>
	<title>exams</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	
	<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">

	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<style type="text/css">
	.exams a{
		text-decoration: none;
	}
	@media screen and (max-width: 900px){
  div.exams i{
   		font-size: 32px;
  }
  div.exams li{
  	width:100px;
  	height:100px;
  }
}




</style>

</head>
<body>
	

<div class="course">

	<h1 style="text-align: center;padding:10px;color:blue;font-size: 28px;background-color: white">WE ALWAYS WELCOME YOU...</h1>

	<h1  style="text-align: center;">practice best question for here!!</h1>
	<p  style="overflow: hidden;text-align: center;font-size: 20px;font-weight: bold;"> practise thousand of question created by experts & topper and review answer with detailed students,track your progress with performance analysis and master all your subject at no cost</p></div>

<div class="exams">
	<ul>
		<div style="text-align: center;">
	
<li><a href="railways.php"><i class='fa fa-train fa-4x' style="color: red;padding: 10px;"></i><h3>Railways</h3></a></li>
<li><a href="sscjee.php"><i class='fas fa-award fa-4x' style="color: blue;padding: 10px;"></i><h3>IIT JEE</h3></a></li>
<li><a href="gate.php"><i class="fas fa-tools fa-4x" style="color: #00ff00; padding: 10px;"></i><h3>Gate Exams</h3></a></li>
<li><a href="cs.php"><i class="fa fa-desktop fa-4x" style="color: #845992; padding: 10px;"></i><h3>CS Exams</h3></a></li>
<li><a href="ssc.php"><i class="fa fa-bank fa-4x" style="color: #210474; padding: 10px;"></i><h3>SSC</h3></a></li>
<li><a href="tnpsc.php"><i class="fa fa-globe fa-4x" style="color: #023787; padding: 10px;"></i><h3>TNPSC</h3></a></li>
<li><a href="aptitude.php"><i class="fas fa-book-reader fa-4x" style="color: #129144; padding: 10px;"></i><h3>APTITUDE</h3></a></li>
<li><a href="upse.php"><i class="fa fa-graduation-cap fa-4x" style="color: #210837; padding: 10px;"></i><h3>UPSC</h3></a></li>
<li><a href="defence.php"><i class="fa fa-life-ring fa-4x" style="color: #194782; padding: 10px;"></i><h3>DEFENCE</h3></a></li>
<li><a href="bankpo.php"><i class="fa fa-balance-scale fa-4x" style="color: #961263; padding: 10px;"></i><h3>BANK/PO</h3></a></li>
<li><a href="airways.php"><i class="fa fa-plane fa-4x" style="color: #172399; padding: 10px;"></i><h3>AIRWAYS</h3></a></li>
<li><a href="net.php"><i class="fa fa-book fa-4x" style="color: #617278; padding: 10px;"></i><h3>NET</h3></a></li>

	 
	 </div>

</ul>
	
</div>








</body>
</html>