<!DOCTYPE html>
<html>

<head>
	<title>signin</title>
</head>
<body>

 

  <div id="form">
    <form action="users.php"  method="POST">

	
  <h1 style="text-align: center;font-family: timesofindia;">Create your free account</h1><br><br>

  <div style="text-align: center;font-family: timesofindia">FULLNAME : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="fullname" name="username"></div><br><br>

  <div style="text-align: center;font-family: timesofindia">EMAIL : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&ensp;&nbsp;<input type="text" id="email"name="email"></div><br><br>

  <div style="text-align: center;font-family: timesofindia;overflow: hidden;">MOBILE :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="phone" id="mobile" name="phone"></div><br><br>

  <div style="text-align: center;font-family: timesofindia">PASSWORD : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" id="password" name="password"></div><br><br>

  <div style="text-align: center;font-family: timesofindia"><button style="padding:5px;width: 30%;">SIGNUP</button></div>

  <h3 style="text-align: center;">already have an account</h3>
  
  <div style="text-align: center;padding:10px;"><a href="login.php">LOGIN</a></div>
</form>
</div>

  </body>
  </html>