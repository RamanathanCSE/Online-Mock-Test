<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="header">
		<a href="images.png">LOGO</a>
	<div class="header-menu">
		<a href="exams.php">EXAMS</a>
		<a href="course.php">COURSE</a>
		<a href="signin.php">SIGN IN</a>
		<a href="signin.php">FEEDBACK</a>
    </div>
   <style type="text/css">
#container { width: 50%; //whatever width you want }

#image {width: 100%; //fill up whole div }

#text { text-align: justify; }    
</style>

 <div id="container"> 
     <img src="bg1.jpg" id="image" /> 
     <p id="text">oooh look! text!</p> 
 </div>





</div>

</body>
</html>