<!DOCTYPE html>
<head>
<title>QUESTION BANK</title>

<style type="text/css">
body{
    margin: 0;
    padding: 0;
    background: url(sm.jpg)no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    font-family: sans-serif;

}
a{
  padding : 20px;
  margin-left:30px; 
  color: white;
}

.menu {
  padding: 18px;
  background-color: green;
}
.menu a{
    font-family: timesofindia;
      line-height: 60px;
      font-size: 22px;
      margin: 0 auto;
}

article{
	width:auto;
	overflow-x :auto;
}

.tab1{
	background: #f5f5f5;
    width: 80%;
    font-family: sans-serif;
    font-weight:normal; 
    padding: 10px;
	border-radius: 20px;
	margin:10px;
	overflow-x: auto;
    display: inline-block;
}

.tab1 a{
    color: black;
    margin-right: 40px;
    font-size: 18px;
    text-align:center;
}
table ,tr ,td{
    border-collapse: collapse;
    padding: 20px;
    float: center;
    width: 100%;
}
td{
    text-align: left;
}
h3{
    text-shadow: 4px 2px 5px BLUE; 
    font-size: 20px;
    background: gray;
    padding: 10px;
    border-radius: 10px;   
}
 
</style>    
</head>
<body>
<div class="menu">
  <a href="/vishnu/index1.php">Home</a>
  <a href="/vishnu/railways.php">RAILWAYS</a>
  <a href="/vishnu/feedback.php">Feedback</a>

</div>
  <h4 style="text-align: center;font-size: 20px">DOWNLOAD YOUR STUDY MATERIALS AND QUESTION PAPERS</h4>
 <article>
<section style="text-align: center;">
 <div class="tab1">
<table border="1px solid gray;" >
  <h3>RAILWAY Question Banks</h3>
    <tr>
        <th>PDF'S</th>
        <th>Download</th> 
        
        <tr><td>
1425618559610-QP ALP.pdf</td><td><a href="

https://drive.google.com/file/d/1PYLFpjhRK-GS_wCE6sccLnx1tqmLP8Bn/preview

">view</a></td></tr>
        <tr><td>
1425619362555-QP CI.pdf</td><td><a href="https://drive.google.com/file/d/1ZDoIuT60wGob5--I9zIJ9xafwusawzkp/preview

">view</a></td></tr>

        <tr><td>
1425619902684-QP Loco Inspectors.pdf</td><td><a href="
https://drive.google.com/file/d/1Uu1oVtFCPhWK_caFCqFQiBjE4Mu5jDDQ/preview
">view</a></td></tr>
     <tr><td>
1441956126262-QP Goods Guard 15 percent LDCE 29012015.pdf
</td><td><a href="https://drive.google.com/file/d/1QxLgIgKSHf4_Cj1nkaJDVzzULSxTFFeJ/preview
">view</a></td></tr>
   
        <tr><td>
1444912376820-QP Ticket Examiner 33 1-3.pdf</td><td><a href="https://drive.google.com/file/d/1zrVtT3TDg5cd9vBnWwbCrRblN_6WRrPe/preview
">view</a></td></tr>
        <tr><td>

1450939295523-QB 4200 OPTG.pdf</td><td><a href="
https://drive.google.com/file/d/1WV9onPsmY_Jw9DTFQj91o2ygsG8toKQ8/preview
">view</a></td></tr>
     <tr><td>
1493621066705-CGA JE SNT.pdf
</td><td><a href="https://drive.google.com/file/d/1iRLJgbh6Q35QT0aDLZCN-jkNRgIY0UpN/preview
">view</a></td></tr>
   <tr><td>Ticket Examiner Model Question Paper 2.pdf
</td><td><a href="https://drive.google.com/file/d/1wVNA3xJc263Eukr4QYYGTOZoULnV2zt7/preview
">view</a></td></tr>
  

   
    </tr>
    </tr>
  </table>
 </div>
</section>
</article>
