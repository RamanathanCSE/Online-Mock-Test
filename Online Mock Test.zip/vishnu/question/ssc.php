<!DOCTYPE html>
<head>
<title>QUESTION BANK</title>

<style type="text/css">
body{
    margin: 0;
    padding: 0;
    background: url(sm.jpg)no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    font-family: sans-serif;

}
a{
  padding : 20px;
  margin-left:30px; 
  color: white;
}

.menu {
  padding: 18px;
  background-color: green;
}
.menu a{
    font-family: timesofindia;
      line-height: 60px;
      font-size: 22px;
      margin: 0 auto;
}

article{
	width:auto;
	overflow-x :auto;
}

.tab1{
	background: #f5f5f5;
    width: 80%;
    font-family: sans-serif;
    font-weight:normal; 
    padding: 10px;
	border-radius: 20px;
	margin:10px;
	overflow-x: auto;
    display: inline-block;
}

.tab1 a{
    color: black;
    margin-right: 40px;
    font-size: 18px;
    text-align:center;
}
table ,tr ,td{
    border-collapse: collapse;
    padding: 20px;
    float: center;
    width: 100%;
}
td{
    text-align: left;
}
h3{
    text-shadow: 4px 2px 5px BLUE; 
    font-size: 20px;
    background: gray;
    padding: 10px;
    border-radius: 10px;   
}
 
</style>    
</head>
<body>
<div class="menu">
  <a href="/vishnu/index1.php">Home</a>
  <a href="/vishnu/ssc.php">SSC</a>
  <a href="/vishnu/feedback.php">Feedback</a>

</div>
  <h4 style="text-align: center;font-size: 20px">DOWNLOAD YOUR STUDY MATERIALS AND QUESTION PAPERS</h4>
 <article>
<section style="text-align: center;">
 <div class="tab1">
<table border="1px solid gray;" >
  <h3>
SSC Question Banks</h3>
    <tr>
        <th>PDF'S</th>
        <th>Download</th> 
        
        <tr><td>

SSC CGL 12th April 2022 Shift-3 by Cracku.pdf</td><td><a href="
https://drive.google.com/file/d/1HBQqXO2BFImTVi30rAh8h5BCi4C3SJ2w/preview

">view</a></td></tr>
        <tr><td>
SSC CGL 13th April 2022 Shift-3 by Cracku.pdf
</td><td><a href="
https://drive.google.com/file/d/1cOGSpS314fwnfXT6P0qa6UtmAj1VMe4u/preview
">view</a></td></tr>

        <tr><td>
SSC CGL 20th April 2022 Shift-2 by Cracku.pdf
</td><td><a href="
https://drive.google.com/file/d/1SZrYCWJ2rECceHD65maodfNVGF66yGiu/preview

">view</a></td></tr>
     
     <tr><td>
SSC CGL 20th April 2022 Shift-3 by Cracku.pdf</td><td><a href="
https://drive.google.com/file/d/1Ey9RA4KVDhsxmZPm7cnibiBmHZksdObE/preview"
>view</a></td></tr>   
        <tr><td>

SSC CGL 21st April 2022 Shift-1 by Cracku.pdf</td><td><a href="https://drive.google.com/file/d/1I9jwNSoh4r3JNfZZpsTXnB3qEz5QKFwu/preview

">view</a></td></tr>
        <tr><td>
SSC CGL 21st April 2022 Shift-2 by Cracku.pdf</td><td><a href="
https://drive.google.com/file/d/14Xqn41r5XJ7ZkvJZE8ra4IpTtSTuPcJu/preview
">view</a></td></tr>
     <tr><td>
SSC CGL 21st April 2022 Shift-3 by Cracku.pdf
</td><td><a href="
https://drive.google.com/file/d/1zSuoHCeMGlkJ_Hd1ntPpY7iRaYC2RM6s/preview
">view</a></td></tr>
   <tr><td>
ssc-cgl-2022-notification.pdf</td><td><a href="
https://drive.google.com/file/d/19CV1c13powuKD_VN88TNDmP05NwpZ-uj/preview
">view</a></td></tr>
  
    </tr>
    </tr>
  </table>
 </div>
</section>
</article>
