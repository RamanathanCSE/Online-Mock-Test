<!DOCTYPE html>
<head>
<title>QUESTION BANK</title>

<style type="text/css">
body{
    margin: 0;
    padding: 0;
    background: url(sm.jpg)no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    font-family: sans-serif;

}
a{
  padding : 20px;
  margin-left:30px; 
  color: white;
}

.menu {
  padding: 18px;
  background-color: green;
}
.menu a{
    font-family: timesofindia;
      line-height: 60px;
      font-size: 22px;
      margin: 0 auto;
}

article{
	width:auto;
	overflow-x :auto;
}

.tab1{
	background: #f5f5f5;
    width: 80%;
    font-family: sans-serif;
    font-weight:normal; 
    padding: 10px;
	border-radius: 20px;
	margin:10px;
	overflow-x: auto;
    display: inline-block;
}

.tab1 a{
    color: black;
    margin-right: 40px;
    font-size: 18px;
    text-align:center;
}
table ,tr ,td{
    border-collapse: collapse;
    padding: 20px;
    float: center;
    width: 100%;
}
td{
    text-align: left;
}
h3{
    text-shadow: 4px 2px 5px BLUE; 
    font-size: 20px;
    background: gray;
    padding: 10px;
    border-radius: 10px;   
}
 
</style>    
</head>
<body>
<div class="menu">
  <a href="/vishnu/index1.php">Home</a>
  <a href="/vishnu/bankpo.php">BANKPO</a>
  <a href="/vishnu/feedback.php">Feedback</a>

</div>
  <h4 style="text-align: center;font-size: 20px">DOWNLOAD YOUR STUDY MATERIALS AND QUESTION PAPERS</h4>
 <article>
<section style="text-align: center;">
 <div class="tab1">
<table border="1px solid gray;" >
  <h3>BANK EXAM Question Banks</h3>
    <tr>
        <th>PDF'S</th>
        <th>Download</th> 
        <tr><td>
Banking-NABARD-General-English-2
</td><td><a href="https://drive.google.com/file/d/1HGOVZuARnsBsCzkEBluLbtS8omSgiG5h/preview
">view</a></td>
        <tr><td>
BOM-Model-Paper-2020</td><td><a href="
https://drive.google.com/file/d/1OQACiv3ky-UOGmcmDYBuX8Mk5OmSfYzi/preview
">view</a></td></tr>
        <tr><td>
ESI-MOCK-TEST-2018-I</td><td><a href="https://drive.google.com/file/d/1MFJM_kpL63TYkrOyVLsSodAQwHf9ci5a/preview
">view</a></td></tr>
        <tr><td>Haryana-High-Court-Clerk-QP-Final</td><td><a href="
https://drive.google.com/file/d/1mdck74Jr78dnrElv2F_FIUKAc8tu_dd1/preview
">view</a></td></tr>
     <tr><td>
IBPS-RRB-GBO-previous-Paper-2022
</td><td><a href="https://drive.google.com/file/d/1SmGVhdD409EgFv1O6duMfq4wda7cGqJd/preview
">view</a></td></tr>
   
        <tr><td>
IBPS-RRB-GBO-SCALE-2-Memory-based-paper</td><td><a href="https://drive.google.com/file/d/1Ue1f8W92Aqran0hqoXSM0nipK9DErMZ6/preview
">view</a></td></tr>
        <tr><td>
IBPS-RRB-GBO-Scale-2-Previous-Paper-</td><td><a href="
https://drive.google.com/file/d/1rKJfwK7eGs9e4ig-hl_ebKrCyb7Uhc9L/preview
">view</a></td></tr>
     <tr><td>
IBPS-SO-Mains-2020-Question-Paper
</td><td><a href="https://drive.google.com/file/d/1aBiSF62mBjQmfIF0adDxMwZSyYW1CJmb/preview
">view</a></td></tr>
   <tr><td>

IBPS-SO-Marketing-Officer-Model-Paper-2019-20</td><td><a href="https://drive.google.com/file/d/13x3olBNMOYliDViNPG-Mj-JSJmai7OBs/preview
">view</a></td></tr>
     <tr><td>
IBPS+PO+PT+Set+7.pdf"
</td><td><a href="https://drive.google.com/file/d/1FSgzG8y-QEtgY2auyGdwefBCOIi1U6GO/preview

">view</a></td></tr>
      

   
    </tr>
    </tr>
  </table>
 </div>
</section>
</article>
