<table bgcolor="#62A2D1" width="100%">
  <tr>
    <td>
    <p style="font-family:Verdana;font-size:14px; margin-bottom:40px; text-align:center;"><strong><br/>
    Designed by:  vishnukumar<br/><br/>
    Copyright &copy; - 2020
    </strong>
    </p>
    </td>
  </tr>
</table>