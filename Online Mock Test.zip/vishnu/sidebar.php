<!DOCTYPE html>
<html lang="en">
<head>
	<meta charsett="UTF-8">
	<title>sidebar</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
	<div class="sidebar">
		<div class="sidebar1">
			<h2>sidebar</h2>
			<ul>
				<li><a href="#"><i class="fas fa-home"></i>home</a></li>
				<li><a href="#"><i class="fas fa-dashboard"></i>dashboard</a></li>
				<li><a href="#"><i class="fas fa-test"></i>exams</a></li>
				<li><a href="#"><i class="fas fa-course"></i>course</a></li>
				<li><a href="#"><i class="fas fa-about"></i>About Us</a></li>
				<li><a href="#"><i class="fas fa-contact"></i>contact</a></li>
				<li><a href="#"><i class="fas fa-login"></i>login</a></li>
				
			</ul>
			<div class="social_media">
				<a href="#"><i class="fas fa-home"></i></a>
				<a href="#"><i class="fas fa-home"></i></a>
				<a href="#"><i class="fas fa-home"></i></a>
			</div>

		</div>
		<div class="content">
			<div class="header">welcome!! have a nice day..</div>
			<div class="header1">
				<div>vishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnu</div>
				<div>vishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnu</div>
				<div>vishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuv>vishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnuvishnu</div>
				
			</div>

</div>
</body>
</html>