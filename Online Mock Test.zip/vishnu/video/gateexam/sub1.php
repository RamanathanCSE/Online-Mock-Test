<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

	<link rel="stylesheet" type="text/css" href="style_video.css">

</head>
<body>
<div class="wrapper">
	<div class="videowrapper">
<iframe src="https://www.youtube.com/embed/fEQd43lg9x8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe  style="left:40%; "  src="https://www.youtube.com/embed/jj2HAvp51sU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe  style="left:80%; "src="https://www.youtube.com/embed/xc2R1isOMyE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>
</div>
</body>
</html>
