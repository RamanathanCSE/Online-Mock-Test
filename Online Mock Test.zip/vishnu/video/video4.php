<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> VIDEOS	</title>
<link rel="stylesheet" type="text/css" href="style_video.css">
</head>

<body>
<article>

<div class="wrapper">
	
<section >
	<div class="video">
	<div class="videotitle">
		<h3>REFERENCE</h3>
	</div>	
	<div class="videowrapper">
<iframe  src="./csexams/sub1.php" frameborder="0" width="100%" height="200px" ></iframe></div>
	</div>

</div>
</section>
<br>
<section style="left: 20%">
<div class="wrapper">

<div class="video">
	<div class="videotitle">
		<h3>OTHERS</h3>
	</div>	
	<div class="videowrapper2">
<iframe  style="top:60%" src="./csexams/sub2.php" frameborder="0" width="100%" height="200px" ></iframe>
</div>
	</div>

</section>
</article>
</body>
</html>